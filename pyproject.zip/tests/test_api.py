from fastapi.testclient import TestClient
from app.main import app
from app.api.dependencies import get_llm_client

# 1. Create a Fake LLM Client to bypass Ollama for fast testing
class MockLLMClient:
    def __init__(self, should_pass: bool = True):
        self.should_pass = should_pass

    def review_code(self, code_snippet: str):
        # Instantly return a fake JSON response
        return {
            "All variables have meaningful names": self.should_pass,
            "Docstring of function reflects the actual code's logic": self.should_pass
        }

# 2. Tell FastAPI to use the Fake LLM instead of the real one
def override_get_llm_client_pass():
    return MockLLMClient(should_pass=True)

def override_get_llm_client_fail():
    return MockLLMClient(should_pass=False)

# Initialize the test browser
client = TestClient(app)


def test_no_file_uploaded():
    """Test what happens if the user forgets to attach a file."""
    response = client.post("/scan")  # No file attached
    assert response.status_code == 422  # 422 is FastAPI's standard "Validation Error"


def test_non_python_file():
    """Test what happens if the user uploads a .txt file."""
    files = {"file": ("document.txt", b"Hello world", "text/plain")}
    response = client.post("/scan", files=files)
    
    assert response.status_code == 400
    assert response.json()["detail"] == "Only .py files are supported."


def test_good_python_file():
    """Test a valid upload where the AI passes the code."""
    # Apply the Mock LLM that returns TRUE
    app.dependency_overrides[get_llm_client] = override_get_llm_client_pass
    
    files = {"file": ("good_code.py", b"def foo(): pass", "text/plain")}
    
    # Upload the file
    post_response = client.post("/scan", files=files)
    assert post_response.status_code == 202
    
    # Get the ID and fetch the results
    scan_id = post_response.json()["scan_id"]
    get_response = client.get(f"/results/{scan_id}")
    
    assert get_response.status_code == 200
    results = get_response.json()
    
    # Because we mocked the LLM, it should be COMPLETED instantly and return True
    assert results["status"] == "COMPLETED"
    assert results["results"]["All variables have meaningful names"] is True
    
    # Clean up the override for the next test
    app.dependency_overrides.clear()


def test_bad_python_file():
    """Test a valid upload where the AI fails the code."""
    # Apply the Mock LLM that returns FALSE
    app.dependency_overrides[get_llm_client] = override_get_llm_client_fail
    
    files = {"file": ("bad_code.py", b"def x(): a=1", "text/plain")}
    
    post_response = client.post("/scan", files=files)
    scan_id = post_response.json()["scan_id"]
    
    get_response = client.get(f"/results/{scan_id}")
    assert get_response.json()["results"]["All variables have meaningful names"] is False
    
    app.dependency_overrides.clear()