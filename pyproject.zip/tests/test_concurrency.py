import concurrent.futures
import requests

# We run this against your LIVE local server
URL = "http://localhost:8000/scan"

def send_upload_request(worker_id: int):
    """Sends a single POST request."""
    # We use a tiny file just to get past the FastAPI router validation
    files = {"file": (f"test_load_{worker_id}.py", b"print('hello')", "text/plain")}
    response = requests.post(URL, files=files)
    return response.status_code

def test_system_max_capacity():
    """
    Fires 6 requests at the exact same time.
    Expects exactly five 202 (Accepted) and one 503 (Service Unavailable).
    """
    # 1. Fire 6 requests in parallel
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
        # executor.map runs them all simultaneously
        status_codes = list(executor.map(send_upload_request, range(6)))

    # 2. Count the results
    success_count = status_codes.count(202)
    rejection_count = status_codes.count(503)

    # 3. Assert the architectural rules held up!
    print(f"\nResults: {success_count} Accepted, {rejection_count} Rejected.")
    assert success_count == 5, "System did not accept exactly 5 requests."
    assert rejection_count == 1, "System did not correctly reject the 6th request."